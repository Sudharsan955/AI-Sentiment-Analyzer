"""
==============================================
   AI Sentiment Analyzer - Basic Level
   Powered by Claude (Anthropic API)
==============================================

Features:
  - Analyze sentiment of any text (Positive / Negative / Neutral)
  - Shows confidence score and reason
  - Analyze single text or a batch from a .txt file
  - Saves results to a report file

Requirements:
  pip install anthropic
"""

import anthropic
import json
import os
from datetime import datetime

# ---- CONFIG ----
client = anthropic.Anthropic()   # Reads ANTHROPIC_API_KEY from environment
MODEL  = "claude-sonnet-4-6"


# ------------------------------------------------
# Core: Ask Claude to analyze sentiment
# ------------------------------------------------
def analyze_sentiment(text: str) -> dict:
    """Send text to Claude and get structured sentiment analysis."""

    prompt = f"""Analyze the sentiment of the following text.
Respond ONLY with a valid JSON object — no markdown, no explanation outside JSON.

JSON format:
{{
  "sentiment": "Positive" | "Negative" | "Neutral",
  "confidence": 0.0 to 1.0,
  "reason": "one short sentence explaining the sentiment"
}}

Text to analyze:
\"\"\"{text}\"\"\"
"""

    response = client.messages.create(
        model=MODEL,
        max_tokens=256,
        messages=[{"role": "user", "content": prompt}]
    )

    raw = response.content[0].text.strip()

    # Strip any accidental markdown fences
    raw = raw.replace("```json", "").replace("```", "").strip()

    result = json.loads(raw)
    return result


# ------------------------------------------------
# Display helpers
# ------------------------------------------------
EMOJI = {"Positive": "😊", "Negative": "😠", "Neutral": "😐"}
BAR   = {"Positive": "▓", "Negative": "░", "Neutral": "▒"}

def confidence_bar(score: float, width: int = 20) -> str:
    filled = int(score * width)
    char   = "█"
    return char * filled + "─" * (width - filled)

def print_result(text: str, result: dict, index: int = None):
    label   = result.get("sentiment", "Unknown")
    conf    = result.get("confidence", 0.0)
    reason  = result.get("reason", "")
    emoji   = EMOJI.get(label, "❓")

    prefix = f"  [{index}] " if index is not None else "  "
    short_text = (text[:60] + "...") if len(text) > 60 else text

    print(f"\n{prefix}Text     : \"{short_text}\"")
    print(f"  Sentiment : {emoji}  {label}")
    print(f"  Confidence: [{confidence_bar(conf)}] {conf*100:.0f}%")
    print(f"  Reason    : {reason}")


# ------------------------------------------------
# Modes
# ------------------------------------------------
def single_mode():
    print("\n--- Single Text Analysis ---")
    text = input("  Enter text: ").strip()
    if not text:
        print("  [!] Empty input.")
        return
    print("  Analyzing...")
    try:
        result = analyze_sentiment(text)
        print_result(text, result)
    except Exception as e:
        print(f"  [ERROR] {e}")


def batch_mode():
    print("\n--- Batch Analysis (from file) ---")
    filepath = input("  Enter path to .txt file (one sentence per line): ").strip()

    if not os.path.isfile(filepath):
        print(f"  [ERROR] File not found: {filepath}")
        return

    with open(filepath, "r", encoding="utf-8") as f:
        lines = [l.strip() for l in f.readlines() if l.strip()]

    if not lines:
        print("  [!] File is empty.")
        return

    print(f"\n  Found {len(lines)} line(s). Analyzing...\n" + "─" * 45)

    results = []
    for i, line in enumerate(lines, 1):
        try:
            result = analyze_sentiment(line)
            print_result(line, result, index=i)
            results.append({"text": line, **result})
        except Exception as e:
            print(f"  [{i}] ERROR: {e}")

    # Summary
    sentiments = [r["sentiment"] for r in results]
    pos = sentiments.count("Positive")
    neg = sentiments.count("Negative")
    neu = sentiments.count("Neutral")

    print("\n" + "─" * 45)
    print(f"  SUMMARY — Total: {len(results)}  |  "
          f"😊 Positive: {pos}  |  😠 Negative: {neg}  |  😐 Neutral: {neu}")

    # Save report
    save = input("\n  Save report to file? (yes/no): ").strip().lower()
    if save in ("yes", "y"):
        save_report(results, filepath)


def save_report(results: list, source_file: str):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_file  = f"sentiment_report_{timestamp}.txt"

    with open(out_file, "w", encoding="utf-8") as f:
        f.write(f"Sentiment Analysis Report\n")
        f.write(f"Generated : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Source    : {source_file}\n")
        f.write("=" * 50 + "\n\n")

        for i, r in enumerate(results, 1):
            f.write(f"[{i}] Text      : {r['text']}\n")
            f.write(f"    Sentiment : {r['sentiment']}\n")
            f.write(f"    Confidence: {r['confidence']*100:.0f}%\n")
            f.write(f"    Reason    : {r['reason']}\n\n")

        sentiments = [r["sentiment"] for r in results]
        f.write("=" * 50 + "\n")
        f.write(f"SUMMARY: Positive={sentiments.count('Positive')}  "
                f"Negative={sentiments.count('Negative')}  "
                f"Neutral={sentiments.count('Neutral')}\n")

    print(f"  Report saved → {out_file}")


# ------------------------------------------------
# Main menu
# ------------------------------------------------
def main():
    print("\n" + "=" * 45)
    print("   🧠  AI Sentiment Analyzer  (Claude)")
    print("=" * 45)
    print("  Powered by Anthropic Claude API\n")

    while True:
        print("  Choose mode:")
        print("  [1] Analyze a single text")
        print("  [2] Batch analyze from a .txt file")
        print("  [3] Quit")

        choice = input("\n  Your choice: ").strip()

        if choice == "1":
            single_mode()
        elif choice == "2":
            batch_mode()
        elif choice in ("3", "q", "quit"):
            print("\n  Goodbye! 👋\n")
            break
        else:
            print("  [!] Invalid choice. Enter 1, 2, or 3.")

        print()


if __name__ == "__main__":
    main()
